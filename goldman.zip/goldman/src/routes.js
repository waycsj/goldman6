import { createBrowserRouter } from "react-router-dom";
import Shop from "./Shop";
import ShopApplicationWrapper from "./pages/ShopApplicationWrapper";
import ProductListPage from "./pages/ProductListPage/ProductListPage";
import ProductDetails from "./pages/ProductDetailPage/ProductDetails";
import { loadProductById } from "./routes/products";


export const router = createBrowserRouter([
    {
      path: "/",
      element: <ShopApplicationWrapper />,
      children:[
        {
            path:"/",
            element:<Shop />
        },
        {
            path:"/women",
            element:<ProductListPage categoryType={'WOMEN'}/>,
        },
        {
          path:"/men",
          element:<ProductListPage categoryType={'MEN'}/>,
        },
        {
          path:"/product/:productId",
          loader: loadProductById,
          element: <ProductDetails />
        }
      ]
    }
  ]);


//ProductDetails 파일이 빠진듯....
//SvgCloth.js파일도
//SvgCreditCard.js파일도
//SvgReturn.js파일도 
//SvgShipping.js파일도 빠진듯

//이 파일 자체를 손봐야함.
//AI가 32-34 틀렸다고 함.