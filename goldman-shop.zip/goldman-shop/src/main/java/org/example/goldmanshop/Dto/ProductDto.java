package org.example.goldmanshop.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

public class ProductDto {
//
//  private UUID id;
//  private String name;
//
//  // 기본 생성자
//  public ProductDto() {}
//
//  // 생성자
//  public ProductDto(UUID id, String name) {
//    this.id = id;
//    this.name = name;
//  }
//
//  // Getter와 Setter
//  public UUID getId() {
//    return id;
//  }
//
//  public void setId(UUID id) {
//    this.id = id;
//  }
//
//  public String getName() {
//    return name;
//  }
//
//  public void setName(String name) {
//    this.name = name;
//  }
}
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductDto {

  private UUID id;
  private String name;
  private String description;
  private BigDecimal price;
  private String brand;
  private boolean isNewArrival;
  private Float rating;
  private UUID categoryId;
  private String categoryName;
  private UUID categoryTypeId;
  private String categoryTypeName;
  private List<ProductVariantDto> variants;
  private List<ProductResourceDto> productResources;
}