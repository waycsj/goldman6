package org.example.goldmanshop.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Entity
@Table(name = "prodict-variant")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class ProductVariant {
  @Id
  @GeneratedValue
  private UUID id;

  private String Color;

  @Column(nullable = false)
  private String size;

  @Column(nullable = false)
  private Integer stockQuantity;

  @ManyToOne
  @JoinColumn(name = "product_id", nullable = false)
  private Product product;

  @Column(nullable = false)
  private String brand;

  @Column(nullable = false)
  private boolean isNewArrival;

  @Column(nullable = false, updatable = false)
  @Temporal(TemporalType.TIMESTAMP)
  private java.util.Date createdAt;

  @Column(nullable = false)
  @Temporal(TemporalType.TIMESTAMP)
  private java.util.Date updatedAt;

  //@OneToMany(mappedBy = "product", cascade = CascadeType.ALL) : 이해가 안된다.
  @PrePersist
  protected void onCreate() {
    createdAt = new java.util.Date();
    updatedAt = createdAt;
  }

  @PreUpdate
  protected void onUpdate() {
    updatedAt = new java.util.Date();
  }
}


